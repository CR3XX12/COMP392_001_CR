#include "battle_simulator.h"
#include <iostream>
using namespace std;

// Constructor definition
BattleSimulator::BattleSimulator() : teamA(3, 1), teamB(3, 1) {} // 3 Soldiers, 1 Queen each

// Start battle definition
void BattleSimulator::startBattle() {
    int round = 1;
    while (teamA.isTeamAlive() && teamB.isTeamAlive()) {
        cout << "Round " << round++ << ":\n";
        teamA.attackOpponent(teamB);
        teamB.attackOpponent(teamA);
    }

    if (teamA.isTeamAlive())
        cout << "Team A wins!\n";
    else
        cout << "Team B wins!\n";
}