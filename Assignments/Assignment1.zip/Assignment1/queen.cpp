#include "queen.h"

// Constructor definition
Queen::Queen() : Warrior(150, 20, 25) {} // Queen stats

// getType definition
string Queen::getType() {
    return "Queen";
}