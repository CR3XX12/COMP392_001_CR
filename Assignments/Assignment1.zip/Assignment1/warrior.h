#ifndef WARRIOR_H
#define WARRIOR_H

#include <iostream>
#include <cstdlib>  // For rand()
using namespace std;

class Warrior {
protected:
    int health;
    int power;
    int damagePower;
    int x, y;  // Position on the 10x10 grid

public:
    Warrior(int h, int p, int d); // Constructor declaration
    void move(); // Move declaration
    void attack(Warrior &enemy); // Attack declaration
    bool isAlive(); // Check if alive declaration
    virtual string getType(); // Get type declaration
    int getX(); // Get X position declaration
    int getY(); // Get Y position declaration
    int getHealth(); // Get health declaration
    int getDamagePower(); // Get damagePower declaration
    void printStatus(); // Print status declaration
};

#endif