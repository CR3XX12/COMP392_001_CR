#ifndef TEAM_H
#define TEAM_H

#include "soldier.h"
#include "queen.h"
#include <vector>

class Team {
private:
    vector<Warrior*> warriors;

public:
    Team(int numSoldiers, int numQueens); // Constructor declaration
    bool isTeamAlive(); // Check if team is alive declaration
    void attackOpponent(Team &enemy); // Attack opponent declaration
    Warrior* getRandomAliveWarrior(); // Get random alive warrior declaration
};

#endif