#ifndef SOLDIER_H
#define SOLDIER_H

#include "warrior.h"

class Soldier : public Warrior {
public:
    Soldier(); // Constructor declaration
    string getType() override; // Override getType declaration
};

#endif