#include "warrior.h"

// Constructor definition
Warrior::Warrior(int h, int p, int d) : health(h), power(p), damagePower(d) {
    x = rand() % 10; // Randomize initial position
    y = rand() % 10;
}

// Move definition
void Warrior::move() {
    int dx = (rand() % 3) - 1; // -1, 0, or 1
    int dy = (rand() % 3) - 1;
    x = max(0, min(9, x + dx)); // Keep inside grid bounds
    y = max(0, min(9, y + dy));
}

// Attack definition
void Warrior::attack(Warrior &enemy) {
    enemy.health -= damagePower;
}

// Check if alive definition
bool Warrior::isAlive() {
    return health > 0;
}

// Get type definition
string Warrior::getType() {
    return "Warrior";
}

// Get X position definition
int Warrior::getX() { return x; }

// Get Y position definition
int Warrior::getY() { return y; }

// Get health definition
int Warrior::getHealth() { return health; }

// Get damagePower definition
int Warrior::getDamagePower() { return damagePower; }

// Print status definition
void Warrior::printStatus() {
    cout << getType() << " at (" << x << ", " << y << ") with " << health << " HP.\n";
}