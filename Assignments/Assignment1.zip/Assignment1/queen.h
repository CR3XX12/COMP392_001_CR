#ifndef QUEEN_H
#define QUEEN_H

#include "warrior.h"

class Queen : public Warrior {
public:
    Queen(); // Constructor declaration
    string getType() override; // Override getType declaration
};

#endif