#include "soldier.h"

// Constructor definition
Soldier::Soldier() : Warrior(100, 10, 15) {} // Soldier stats

// getType definition
string Soldier::getType() {
    return "Soldier";
}